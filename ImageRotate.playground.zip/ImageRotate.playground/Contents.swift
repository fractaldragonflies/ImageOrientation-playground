import AppKit
import PlaygroundSupport

let hdcu = FileManager.default.homeDirectoryForCurrentUser
let localdir = hdcu.appendingPathComponent("ƒSwift/FractalPlaygrounds")
let imageurl = localdir.appendingPathComponent("darkmagic.jpg")

// Test every case.
// Test with square, wider then tall, taller than wide images.
enum CGImageOrientation {
    case up
    case down
    case left
    case right
    case upMirrored
    case downMirrored
    case leftMirrored
    case rightMirrored
}

var orientation: CGImageOrientation = .up

extension CGImage {
    
    func orientImage(_ imageOrientation: CGImageOrientation) -> CGImage {
        
        if imageOrientation == .up { return self }
        
        var transform: CGAffineTransform = CGAffineTransform.identity
        let size = NSSize(width: width, height: height)

        switch imageOrientation {
        case .down, .downMirrored:
            transform = transform.translatedBy(x: size.width, y: size.height)
            transform = transform.rotated(by: CGFloat.pi)
            break
        case .left,.leftMirrored:
            transform = transform.translatedBy(x: size.height, y: 0)
            transform = transform.rotated(by: CGFloat.pi/2)
            break
        case .right, .rightMirrored:
             transform = transform.translatedBy(x: 0, y: size.width)
             transform = transform.rotated(by: -CGFloat.pi/2)
             break
        case .up, .upMirrored:
            break
        }
        
        if [.upMirrored, .downMirrored,.leftMirrored, .rightMirrored].contains(imageOrientation) {
            transform = transform.translatedBy(x: size.width, y: 0)
            transform = transform.scaledBy(x: -1, y: 1)
        }
        
        // Graphic context uses new width and height.
        let newSize = [.left,.leftMirrored, .right, .rightMirrored].contains(imageOrientation)
            ? NSSize(width: size.height, height: size.width) : size
        let ctx = CGContext(data: nil, width: Int(newSize.width), height: Int(newSize.height),
                            bitsPerComponent: self.bitsPerComponent, bytesPerRow: 0,
                            space: self.colorSpace!, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
        ctx.concatenate(transform)
        
        // Interestingly, drawing with the original width and height seems give correct drawing?!
        ctx.draw(self, in: NSRect(x: 0, y: 0, width: size.width, height: size.height))

        return ctx.makeImage()!
    }
}

var image = NSImage(contentsOf: imageurl)!
let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil)
 
if let cgImage = cgImage {
    let orientedImage = cgImage.orientImage(.right)
    image = NSImage(cgImage: orientedImage, size: NSZeroSize)
}

